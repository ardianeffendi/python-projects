import task2
import task3


class Editor:
    def __init__(self):
        """
        Initialising the instance which is self.text_lines
        @pre    None
        @post   an instance variable created.
        @complexity O(1) as it is only assigning.
        """
        self.text_lines = task2.ListADT()


    def read_filename(self, filename):
        
        self.text_lines = task3.read_text_file(filename)  # list of strings
        return self.text_lines

    def print_num(self, rest_string):
        """
        prints the line of text at position num, and if no num is given prints all the lines.
        :param rest_string: a number to specify which line to print
        :return: self.text_line which contains all of the strings.
        @pre     rest_string cannot be 0
        @post    List is not changed.
        @complexity O(m) if it goes to the comparison "==". Otherwise O(1)
        """
        # put try and exception later.
        assert rest_string != 0, "Line number cannot be 0"  # check if users gives 0 or not.
        if rest_string == "":
            return self.text_lines
        # positive line number.
        if int(rest_string) > 0:
            return self.text_lines[(int(rest_string)-1)]
        # negative line number.
        elif int(rest_string) < 0:
            text_line = self.text_lines
            return self.text_lines[int(rest_string) + text_line.length]

    def search_string(self, string):
        """
        returns a list with all the line numbers (if any) in which string appears, and then prints the elements of
        the list.
        :param string: string that we need to search
        :return: the list that contains the line number.
        @pre     string cannot be int
        @post    the list is changed.
        @complexity best and worst case:O(m*n^2) where m is the comparison and
                    n is the length of string and array, it has to go through
                    two loops no matter what.
        """
        lst_string = self.text_lines
        temp_lst = task2.ListADT()

        for array in range(lst_string.length):
            for letter in range(len(lst_string[array])):
                current = lst_string[array]
                if string[0] == current[letter]:
                    if string == current[letter:letter+len(string)]:
                        temp_lst.append(array+1)
                        break
        return temp_lst


    def delete_num(self, rest_string):
        """
        deletes the line of text at position num, and deletes all the lines if no num is given.
        :param rest_string:
        :return: None 
        @pre     rest_string cannot be 0
        @post    List is changed 
        @complexity O(m)where m is the comparison
        """
        assert rest_string != 0, "Line number cannot be 0"  # check if users gives 0 or not.

        text_line = self.text_lines  # assigning self.text_lines to text_line
        if rest_string == "":  # if the given input wasn't specified or ""
            self.text_lines = []
        elif int(rest_string) == 0:  # if the given input equals to 0
            raise IndexError  # raise an error

        # positive line number
        elif int(rest_string) > 0:
            if int(rest_string) > self.text_lines.length:
                raise IndexError
            text_line.delete(int(rest_string) - 1)

        # negative line number
        elif int(rest_string) < 0:
            if int(rest_string) < -self.text_lines.length:
                raise IndexError
            text_line.delete(int(rest_string) + text_line.length)

    def insert_num_strings(self, number, list_of_strings=None):
        """

        :param number: the line number that we want to insert a content.
        :param list_of_strings: list of string which will be inserted into.
        :return: None
        @pre     second parameter cannot be empty, otherwise will raise an error.
        @post    list is changed
        @complexity O(n) where n is the array length, we have to allocate
                    new space for new content.
        """
        if list_of_strings != None:
            counter = 0
            line = int(number)  # the line on the file that will get changed.
            while counter < list_of_strings.length:
                if line > 0:  # positive number
                    self.text_lines.length += 1
                    array_length = self.text_lines.length
                    # create a space for new item, down here (for loop)
                    for i in range(line-1, array_length):
                        self.text_lines[array_length] = self.text_lines[array_length - 1]
                        array_length -= 1
                    self.text_lines[line-1] = list_of_strings[counter]
                    counter += 1
                    line += 1
                elif line < 0:
                    self.text_lines.length += 1
                    array_length = self.text_lines.length
                    index0 = int(number) + self.text_lines.length
                    for i in range(index0, array_length):
                        self.text_lines[array_length] = self.text_lines[array_length - 1]
                        array_length -= 1
                    self.text_lines[index0] = list_of_strings[counter]
                    counter += 1
                    line -= 1
        else:
            raise ValueError


    def run():
        """
        This function is to run the interface where users can interact with.
        :return: None
        @pre     None
        @post    List is changed (for a certain command), program runs
        @complexity O(m) for a certain command where m is the comparison
                    of checking the user input. O(m*n) where n is the length
                    of the list which is to iterate the line and print it for
                    command "search".
        """
        self = Editor()
        while True:
            print("\nPlease choose enter a command (e.g. read filename): \n"
                  "read filename\n"
                  "print num\n"
                  "delete num\n"
                  "insert num\n"
                  "search string\n"
                  "quit")
            usr_input = input("Your command? ")

            if usr_input[0:4] == "read":
                try:
                    argument = usr_input[5:]
                    self.read_filename(argument)
                except (FileNotFoundError, AssertionError):
                    print("?")
                    continue

            elif usr_input[0:5] == "print":
                if len(usr_input) == 5:
                    self.print_num("")
                try:
                    argument = usr_input[6:]
                    print(self.print_num(argument))
                except (ValueError, AssertionError):
                    print("?")
                    continue

            elif usr_input[0:6] == "delete":
                try:
                    argument = usr_input[7:]
                    self.delete_num(argument)
                except (ValueError, AssertionError):
                    print("?")
                    continue
            elif usr_input[0:6] == "insert":
                lst = task2.ListADT()
                try:
                    argument = usr_input[7:]
                except (ValueError, AssertionError):
                    print("?")
                while True:
                    line_input = input()
                    if line_input == ".":
                        self.insert_num_strings(argument, lst)
                        break
                    else:

                        lst.append(line_input+"\n")
                        continue
            elif usr_input[0:6] == "search":
                try:
                    argument = usr_input[7:]
                    lst = self.search_string(argument)
                    for i in range(len(lst)): # to print it line by line
                        print(i+1)
                except (AssertionError, ValueError):
                    print("?")
            elif usr_input == "quit":
                break





#Editor.run()


















