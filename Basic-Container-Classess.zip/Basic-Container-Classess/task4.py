import task2
import task3


class Editor:
    def __init__(self):
        """
        Creating a varible instance which is self.text_lines
        @pre        None
        @post       self.text_lines created
        @complexity Best and worst case: O(1)
        """
        self.text_lines = task2.ListADT()


    def read_filename(self, filename):
        """
        reads a file and prints it into a list.
        @return     self.text_lines which is the list that contains each sentence.
        @pre        File must be exist/on the same folder.
        @post       self.text_lines consists of the things from "filename"'s file
        @complexity best and worst case: O(n) where n is the length of the files.
        """
        self.text_lines = task3.read_text_file(filename)  # list of strings
        return self.text_lines

    def print_num(self, rest_string):
        """
        prints the line of text at position num, and if no num is given prints all the lines.
        :param rest_string: a number to specify which line to print
        :return:     None
        @pre         rest_string cannot be 0
        @post        self.text_lines is printed
        @complexity  best case: O(1) where the line number is negative.
                     worst case: O(m) where is the comparison.
        """
        # put try and exception later.
        assert rest_string != 0, "Line number cannot be 0"  # check if users gives 0 or not.
        if rest_string == "":
            print(self.text_lines)
        # positive line number.
        if int(rest_string) > 0:
            print(self.text_lines[(int(rest_string)-1)])
        # negative line number.
        text_line = self.text_lines
        print(self.text_lines[int(rest_string) + text_line.length])



    def delete_num(self, rest_string):
        """
        deletes the line of text at position num, and deletes all the lines if no num is given.
        :param rest_string:
        :return:    None
        @pre        rest_string cannot be 0
        @post       list is changed
        @complexity best case and worst case are O(m) where m is the comparison.
        """
        text_line = self.text_lines  # assigning self.text_lines to text_line
        if rest_string == "":  # if the given input wasn't specified or ""
            self.text_lines = task2.ListADT()
        elif int(rest_string) == 0:  # if the given input equals to 0
            raise IndexError  # raise an error

        # positive line number
        elif int(rest_string) > 0:
            if int(rest_string) > self.text_lines.length:
                raise IndexError
            text_line.delete(int(rest_string) - 1)

        # negative line number
        elif int(rest_string) < 0:
            if int(rest_string) < -self.text_lines.length:
                raise IndexError
            text_line.delete(int(rest_string) + text_line.length)

    def insert_num_strings(self, number, list_of_strings=None):
        """

        :param number: the line number that we want to insert a content.
        :param list_of_strings: list of string which will be inserted into.
        :return: None
        @pre     second parameter cannot be empty, otherwise will raise an error.
        @post    list is changed
        @complexity best case O(n) where n is length of list strings and it does'nt
                    need to go to the for loop.
                    worst case O(n^2) where it has to go to two loops.
        """
        if list_of_strings != None:
            counter = 0
            line = int(number)  # the line on the file that will get changed.
            while counter < list_of_strings.length:
                if line > 0:  # positive number
                    self.text_lines.length += 1
                    array_length = self.text_lines.length
                    # create a space for new item, down here (for loop)
                    for i in range(line-1, array_length):
                        self.text_lines[array_length] = self.text_lines[array_length - 1]
                        array_length -= 1
                    self.text_lines[line-1] = list_of_strings[counter]
                    counter += 1
                    line += 1
                elif line < 0:
                    self.text_lines.length += 1
                    array_length = self.text_lines.length
                    index0 = int(number) + self.text_lines.length
                    for i in range(index0, array_length):
                        self.text_lines[array_length] = self.text_lines[array_length - 1]
                        array_length -= 1
                    self.text_lines[index0] = list_of_strings[counter]
                    counter += 1
                    line -= 1
        else:
            raise ValueError

    def run():
        """
        This function is to run the interface where users can interact with.
        :return: None
        @pre     None
        @post    List is changed (for a certain command), program runs
        @complexity O(m) for a certain command where m is the comparison
                    of checking the user input. O(m*n) where n is the length
                    of the list which is to iterate the line and print it for
                    command "search".
        """
        self = Editor()
        while True:
            print("\nPlease choose enter a command (e.g. read filename): \n"
                  "read filename\n"
                  "print num\n"
                  "delete num\n"
                  "insert num\n"
                  "search string\n"
                  "quit")
            usr_input = input("Your command? ")

            if usr_input[0:4] == "read":
                try:
                    argument = usr_input[5:]
                    self.read_filename(argument)
                except (FileNotFoundError, AssertionError):
                    print("?")
                    continue

            elif usr_input[0:5] == "print":
                if len(usr_input) == 5:
                    self.print_num("")
                try:
                    argument = usr_input[6:]
                    print(self.print_num(argument))
                except (ValueError, AssertionError):
                    print("?")
                    continue

            elif usr_input[0:6] == "delete":
                try:
                    argument = usr_input[7:]
                    self.delete_num(argument)
                except (ValueError, AssertionError):
                    print("?")
                    continue
            elif usr_input[0:6] == "insert":
                lst = task2.ListADT()
                try:
                    argument = usr_input[7:]
                except (ValueError, AssertionError):
                    print("?")
                while True:
                    line_input = input()
                    if line_input == ".":
                        self.insert_num_strings(argument, lst)
                        break
                    else:

                        lst.append(line_input + "\n")
                        continue
            elif usr_input == "quit":
                break

#Editor.run()















