import task2
import task4

def read_text_file(name):
    '''
    takes the name of a text file as input and reads each line of text into a string, returning a list of strings
    associated to the file (i.e., the function converts the text in the file into a list of strings).
    :param name: the name of the file
    :return: listadt
    @pre         None
    @post        listadt is changed
    @complexity  O(n) where n is how many lines are there in the file
    '''

    listadt = task2.ListADT()
    with open(name) as file:
        for line in file:
            listadt.append(line)
        file.close()
        if file.closed:
            return listadt




