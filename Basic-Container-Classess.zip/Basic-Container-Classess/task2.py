import math

class ListADT:
    def __init__(self, size=40):
        '''
        Initialises the appropriate instance variables.
        The default size is 40 if it is not specified in the first place.

        @:return:       a list data structure
        @:param size:   size number of items in containing array, or maxitems of list
        @post           an empty list object is created
        @complexity     best and worst case: the complexity of [None]*size, which it is
                        probably O(size)
        '''
        if size < 40:
            size = 40
        assert 0 < size, "Size must be greater than 0"
        self.length = 0
        self.new_length = 0
        self.the_array = [None] * size
        self.new_list = [None] * size

    def __str__(self):
        '''
        Returns a string representation of the list (returns the empty string if the list is empty).

        @:return:       a string representation of the list
        @:param:        None
        @post           a string is created
        @complexity     Best and worst case : O(n) where n is the length (that is, the number of elements in the list)
        '''

        temp_str = ""
        if self.is_empty():
            return temp_str
        for i in range(self.length):
            if i < self.length - 1:  # avoiding trailing \n
                temp_str = temp_str + str(self.the_array[i])
                continue  # continue the loop
            temp_str = temp_str + str(self.the_array[i])
        return temp_str

    def __len__(self):
        '''
        Returns the length of the list (that is, the number of elements in the list; 0 if empty).

        @:return: the number of elements in the list
        @:param:        None
        @post           None
        @complexity Best and Worst case = O(1)
        '''

        return self.length

    def __getitem__(self, index):
        '''
        Returns the item at index in the list, if index is non-negative. If it
        is negative, it will return the last item if index is -1, the second-to last if index is -2, and so on
        up to minus the length of the list, which returns the first item.
        The function raises an IndexError if index is out of the range -len(self) to len(self)-1.

        :param index:   the index in the list to return
        :return:        the item at index in the list
        @pre            index is integer between zero and len(list)-1 if it is positive.
                        if it is negative, index is between -1 up to minus the length of the list.
        @post           list isn't changed
        @complexity     best and worst case: O(1)
        '''

        try:
            assert int(index) == index  # check whether index is an integer.
            assert -self.length <= index <= self.length-1  # index is within that range.
        except (AssertionError, ValueError):  # if any of those inside the bracket raises, then raise an error.
            raise IndexError('index not an integer within range')
        if index < 0:  # negative index
            return self.the_array[index + self.length]
        return self.the_array[index]

    def __setitem__(self, index, item):
        '''
        Sets the value at index in the list to be item.

        :param index:   the index in the list.
        :param item:    the item which will be in our targeted index.
        :return:        None
        @pre            index is integer between zero and len(list)-1 if it is positive.
                        if it is negative, index is between -1 up to minus the length of the list.
        @post           list is changed in the particular index.
        @complexity     Best and worst case: O(1)
        '''
        get_item = self.the_array[index]  # it will check whether the index is within the range.
        self.the_array[index] = item

    def __eq__(self, other):
        '''
        Returns True if other is a ListADT which is equivalent to this list (that is,
        they have exactly the same elements in the same order (but possibly different capacities), and False
        for any other object.

        :param other:   a ListADT or other object.
        :return:        True if they are equivalent, otherwise False.
        @pre            None
        @post           list is not changed.
        @complexity     Best case :
                        O(m) where m is the comparison and it is found that it is not the same, therefore returning False.
                        Worst case:
                        O(m*n) where m is the comparison and n is the length of the lists (number of elements in the lists)
        '''
        comparable = other
        if comparable == ListADT:
            for i in range(self.length):
                if self.the_array[i] == other.the_array[i]:
                    continue
                else:
                    return False
            return True
        return False

    def insert(self, index, item):
        '''
        Inserts item into self at position index. For example, insert(self, 0, item) inserts the item
        in the first position, shuffling back everything else.

        :param index:   the index where the item will be placed at.
        :param item:    the item that will be placed at
        :return:        None
        @pre            index is within the range (that is, between zero and len(list)-1 if it is positive and
                        index is between -1 up to minus the length of the list if it is negative).
        @post           list is changed.
        @complexity     Best case: 0(1) where index == self.length or -1.
                        Worst case: O(n) where n is the length of the list (that is the number of elements in the list)
        '''

        '''try:
            assert -self.length <= index <= self.length
        except AssertionError:
            raise IndexError'''
        if self.is_full():
            self.increasing(self.length)  # if the list is full,
            # the size of the array is increased to be 1.9 (rounding up) times the current size.

        if index >= 0:  # index is positive
            lst_length = self.length
            for i in range(index, self.length):
                # allocate a free space.
                self.the_array[lst_length] = self.the_array[lst_length - 1]
                lst_length -= 1
            self.the_array[index] = item
            self.length += 1
        elif index < 0:  # if index is negative, it has to iterate backwards
            lst_length = self.length
            self.length += 1
            index0 = index + self.length # convert the negative index to its positive index.
            for i in range(index0, self.length-1):
                # shuffling the item back before inserting a new item into the targeted index.
                self.the_array[lst_length] = self.the_array[lst_length - 1]
                lst_length -= 1
            self.the_array[index0] = item
            

    def delete(self, index):
        '''
        Returns the item at index from the list and deletes it, shuffling all items
        after it towards the start of the list.
        :param index:   the index of item that will get deleted.
        :return:
        @pre            index is within the range
        @post           list is changed
        @complexity     Best and worst case: O(n) where n is the length of the list,
                        and it has to move every index to its position after deletion.
        '''

        check_index = self.the_array[index] # to check my indexing.
        if not self.is_empty():
            found = self.the_array[index]
            if index >= 0:  # index is positive
                for i in range(index, self.length):
                    self.the_array[i] = self.the_array[i+1]
                self.length -= 1
                self.decreasing(self.length)
                return found
            elif index < 0:  # index is negative
                for i in range((index + self.length), self.length):
                    self.the_array[i] = self.the_array[i + 1]
                self.length -= 1
                self.decreasing(self.length)
                return found

    def is_empty(self):
        '''
        Returns true if the length is equal to zero. Otherwise false.

        @:param:        none
        @:return:       True if self.length == 0, otherwise False
        @complexity:    Best and Worse Case = O(1)
        '''

        return self.length == 0

    def is_full(self):
        '''
        Returns true if the array is full which means the items have reached the length of the array. Else, false.

        @:param:        None
        @:return:       True if length == len(self.array), otherwise False.
        @complexity:    Best and Worst case = O(1)
        '''

        return self.length == len(self.the_array)

    def __contains__(self, item):
        '''
        Checks whether the targeted item is in the list or not by traversing the array within its length.
        :param item:        the targeted item
        :return:            True if it is found, else False
        @pre                None
        @post               List is not changed
        @complexity         Best case:
                            O(1) where item is in the first index.
                            Worst case:
                            O(n) where n is the length of the list (that is, the number of elements in the list)
        '''
        for i in range(self.length):
            if item == self.the_array[i]:
                return True
        return False

    def append(self, item):
        '''
        appends the item to the list.
        :param item: the item that will be put into the list.
        :return:     None
        @pre         None
        @post        List is changed because an element has been added and the length is incremented.
        @complexity  O(1)
        '''

        if not self.is_full():
            self.the_array[self.length] = item
            self.length += 1
        else:
            self.increasing(self.length)

    def increasing(self, length):
        '''
        If the list becomes full, the size of the array is increased to be 1.9 (rounding up) times the current size.
        :param length: the length of the list that indicates whether it is full or not.
        :return:       None
        @pre
        @post
        @complexity
        '''
        self.new_list = self.the_array  # temporary array to store the old items
        self.new_length = self.length   # stores our old length
        init_array = ListADT(math.ceil(1.9 * (length)))  # if list is full,
        # the size of the array is increased to be 1.9 (rounding up) times the current size.
        self.the_array = init_array.the_array  # copies back our new list to our old list (extended).
        self.length = 0  # new length
        for i in range(self.new_length):
            # copying the contents of the old list to the new one.
            self.the_array[i] = self.new_list[i]
            self.length += 1

    def decreasing(self, length):
        '''
        the size of the array should decrease by half if the length of the list is less than 1/4 of the size of the array
        (i.e., if the elements in the list occupy less than 1/4 of the available space).
        :param length:
        :return:
        '''
        if length < (math.ceil(1 / 4 * len(self.the_array))):
            self.new_list = self.the_array  # temporary array to store the old items
            '''decrease by half if the length of the list is less than 1/4 of the size of the array (i.e.,
            if the elements in the list occupy less than 1/4 of the available space).'''
            init_array = ListADT(math.ceil(len(self.the_array)//2))
            self.the_array = init_array.the_array  # copies back our new list to our old list (dec).
            self.new_length = self.length
            self.length = 0  # new length
            for i in range(self.new_length):
                #if i < len(self.the_array):
                self.the_array[i] = self.new_list[i]
                self.length += 1


def test_insert():
    x = ListADT()
    for i in range(40):
        x.insert(i, i)
    x.insert(3, 40)
    print(x.the_array)

    y = ListADT()
    for i in range(40):
        y.insert(i, i)
    y.insert(-1, 100)
    y.insert(-2, 300)
    print(y.the_array)




