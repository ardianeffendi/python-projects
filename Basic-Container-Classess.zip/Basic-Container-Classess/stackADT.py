class StackADT:
    def __init__(self, size):
        self.the_array = [None] * size
        self.top = 0

    def size(self):
        return self.top

    def is_empty(self):
        return self.size() == 0

    def is_full(self):
        return self.size() == len(self.the_array)

    def push(self, item):
        if self.is_full():
            raise Exception("The stack is full")
        self.the_array[self.top] = item
        self.top += 1

    def pop(self):
        if self.is_empty():
            raise Exception("The stack is empty")
        self.top -= 1
        item = self.the_array[self.top]
        return item

    def peek(self):
        if self.is_empty():
            raise Exception("The stack is empty")
        return self.the_array[self.top-1]


